<!-- 自動生成ファイル: build/README.md を編集後 node build/build_all.js を実行してください。直接編集しないでください。 -->
# 『ブロック学習帳』 (Gakushucho) - ver9

『ブロック学習帳』は、小学校の基礎から中学校技術科「D 情報の技術」、高等学校「情報Ⅰ」まで対応した、インストール不要・オフラインで動作する統合型プログラミング学習教材パッケージです。

---

## 📁 リポジトリ構造とディレクトリ役割

- **`index.html`** : 統合ポータル画面（「学習者用」および「指導者用」ツールへの入口、簡易セットアップ手順案内）
- **`gakushucho.html`** : 全8章24節の統合単一HTML教材 (`?teach=0` で【学習者モード】、`?teach=1` で【指導者モード】起動)
  - `#setup` : 巻末付録① 📦 オフライン設置・端末別セットアップガイド
  - `#overview` : 巻末付録② 📖 教材概要 ＆ ガイドライン
  - `#news` : 巻末付録③ 🌟 最新のお知らせ ＆ 更新履歴
  - `#teacher_appendix` : 巻末付録④ 📎 観点別評価規準 ＆ 授業展開表
  - `#lesson_plan` : 巻末付録⑤ 📋 全8章 授業詳細指導案・評価規準一覧
- **`worksheets/`** : A4用紙印刷対応のWeb帳票ワークシート全8種ライブラリ (単体閲覧・配布・思考用トグル対応)
- **`build/`** : 正本マスターソース (`build/gakushucho.md`, `build/README.md`) および自動コンパイルビルドスクリプト (`build.js`, `build_all.js`)

---

## 🛠️ 一括コンパイルビルド方法

本パッケージは、`build/gakushucho.md` (正本Markdown) からすべてのHTMLおよび配布用パッケージ (`gakushucho.zip`) を一括自動生成します。このREADME.md自体も `build/README.md` から自動生成されるため、直接編集せず `build/README.md` を編集してください。

```bash
node build/build_all.js
```

---

## 📦 端末別・環境別セットアップ運用

- **① 指導者用端末 (教員PC):** `gakushucho.zip` を全展開して配置（全指導案・解説付きで起動）。
- **② 学習者用端末 (児童・生徒PC):** `gakushucho.zip` を展開後、`js/teach.js` ファイルを削除して配置（指導案非表示で安心起動）。

---

## 📜 ライセンス表記 (LICENSE)

本ソフトウェアは **The MIT License** のもとで公開されています。詳細は [`LICENSE`](./LICENSE) をご参照ください。  
サードパーティコンポーネント (Google Blockly: Apache 2.0) の権利表記は [`NOTICE`](./NOTICE) をご参照ください。
