const fs = require('fs');
const path = require('path');
const { DOMParser, XMLSerializer } = require('@xmldom/xmldom');
global.DOMParser = DOMParser;
global.XMLSerializer = XMLSerializer;

global.Blockly = require('../js/blockly_compressed.js');
require('../js/blocks_compressed.js');
const jsModule = require('../js/javascript_compressed.js');
const pyModule = require('../js/python_compressed.js');
require('../js/dncl_compressed.js');

function getPyGen() {
  if (typeof Blockly !== 'undefined' && Blockly.Python) return Blockly.Python;
  if (typeof python !== 'undefined' && python.pythonGenerator) return python.pythonGenerator;
  if (pyModule && pyModule.pythonGenerator) return pyModule.pythonGenerator;
  return null;
}
function getJsGen() {
  if (typeof Blockly !== 'undefined' && Blockly.JavaScript) return Blockly.JavaScript;
  if (typeof javascript !== 'undefined' && javascript.javascriptGenerator) return javascript.javascriptGenerator;
  if (jsModule && jsModule.javascriptGenerator) return jsModule.javascriptGenerator;
  return null;
}

Blockly.defineBlocksWithJsonArray([
  { "type": "sound_play", "message0": "🎵 音を鳴らす", "previousStatement": null, "nextStatement": null, "colour": 260 },
  { "type": "say_text", "message0": "💬 %1 と言う", "args0": [{"type": "field_input", "name": "TEXT", "text": "こんにちは！"}], "previousStatement": null, "nextStatement": null, "colour": 160 }
]);

const pyG = getPyGen();
if (pyG) {
  const target = pyG.forBlock || pyG;
  target['sound_play'] = function() { return 'play_sound()\n'; };
  target['say_text'] = function(b) { return 'print(' + JSON.stringify(b.getFieldValue('TEXT')) + ')\n'; };
}

const jsG = getJsGen();
if (jsG) {
  const target = jsG.forBlock || jsG;
  target['sound_play'] = function() { return 'playChime();\n'; };
  target['say_text'] = function(b) { return 'sayText(' + JSON.stringify(b.getFieldValue('TEXT')) + ');\n'; };
}

const ws = new Blockly.Workspace();
const xmlText = '<xml xmlns="https://developers.google.com/blockly/xml"><block type="say_text" x="30" y="30"><field name="TEXT">こんにちは！</field><next><block type="sound_play"></block></next></block></xml>';
const dom = Blockly.utils.xml.textToDom(xmlText);
Blockly.Xml.domToWorkspace(dom, ws);

console.log('=== SUCCESS TEST RESULTS ===');
console.log('Python Output:\n' + pyG.workspaceToCode(ws));
console.log('JS Output:\n' + jsG.workspaceToCode(ws));
console.log('DNCL Output:\n' + Blockly.DNCL.workspaceToCode(ws));
