const fs = require('fs');
const path = require('path');

global.Blockly = require('../js/blockly_compressed.js');
require('../js/blocks_compressed.js');
require('../js/dncl_compressed.js');

Blockly.defineBlocksWithJsonArray([
  { "type": "sound_play", "message0": "🎵 音を鳴らす", "previousStatement": null, "nextStatement": null, "colour": 260 },
  { "type": "say_text", "message0": "💬 %1 と言う", "args0": [{"type": "field_input", "name": "TEXT", "text": "こんにちは！"}], "previousStatement": null, "nextStatement": null, "colour": 160 },
  { "type": "move_steps", "message0": "🐾 %1 歩進む", "args0": [{"type": "field_number", "name": "STEPS", "value": 10}], "previousStatement": null, "nextStatement": null, "colour": 230 },
  { "type": "turn_right", "message0": "↪️ 右に %1 度曲がる", "args0": [{"type": "field_number", "name": "DEGREES", "value": 90}], "previousStatement": null, "nextStatement": null, "colour": 230 }
]);

const ws = new Blockly.Workspace();

const b1 = ws.newBlock('say_text');
b1.setFieldValue('こんにちは！', 'TEXT');

const b2 = ws.newBlock('move_steps');
b2.setFieldValue('10', 'STEPS');
b1.nextConnection.connect(b2.previousConnection);

const b3 = ws.newBlock('turn_right');
b3.setFieldValue('90', 'DEGREES');
b2.nextConnection.connect(b3.previousConnection);

const b4 = ws.newBlock('sound_play');
b3.nextConnection.connect(b4.previousConnection);

console.log('=== DNCL Custom Blocks Code Conversion Test ===');
const dnclOutput = Blockly.DNCL.workspaceToCode(ws);
console.log(dnclOutput);
console.log('=== SUCCESS: DNCL Conversion Worked 100% Error-Free ===');
