const fs = require('fs');
const path = require('path');

const htmlPath = path.join(__dirname, '../learn/gakushucho.html');
const htmlContent = fs.readFileSync(htmlPath, 'utf-8');

console.log('=== Inspecting DNCL Script Loading & Handlers in HTML ===');

const dnclScriptIndex = htmlContent.indexOf('dncl_compressed.js');
console.log('1. dncl_compressed.js script tag index:', dnclScriptIndex);

const dnclPreviewLogic = htmlContent.includes("currentLang === 'dncl'");
console.log('2. currentLang === dncl logic present:', dnclPreviewLogic);

// updateCodePreview 関数の DNCL 処理ブロックを抽出表示
const startIdx = htmlContent.indexOf("currentLang === 'dncl'");
if (startIdx !== -1) {
  console.log('=== DNCL Preview Code Snippet ===');
  console.log(htmlContent.substring(startIdx, startIdx + 300));
}
