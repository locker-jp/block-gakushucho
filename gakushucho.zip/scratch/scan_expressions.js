const fs = require('fs');
const path = require('path');

const targetFiles = [
  'build/gakushucho.md',
  'build/docs/ref01_project_overview.md',
  'build/docs/changelog.md',
  'README.md',
  'worksheets/01_screen_design_sheet.html',
  'worksheets/02_state_transition_diagram.html',
  'worksheets/03_debug_trace_table.html',
  'worksheets/04_array_trace_table.html',
  'worksheets/05_dncl_trace_sheet.html',
  'worksheets/06_function_stack_diagram.html',
  'worksheets/07_peer_advice_cards.html',
  'worksheets/08_reflection_sheet.html'
];

// 自然言語における強い表現・過剰な断定表現のパターン
const keywords = [
  '完全', '完璧', '保証', '保障', '100%', '１００％', '100パーセント',
  '絶対', '確実', 'かならず', '必ず', '一切'
];

const results = [];

targetFiles.forEach(relPath => {
  const fullPath = path.resolve(relPath);
  if (!fs.existsSync(fullPath)) return;
  const content = fs.readFileSync(fullPath, 'utf-8');
  const lines = content.split('\n');

  let currentSection = '冒頭・ヘッダー';

  lines.forEach((line, lineIdx) => {
    // 見出しの追跡
    if (line.startsWith('#')) {
      currentSection = line.replace(/^#+\s*/, '').trim();
    } else if (line.includes('SECTION_START')) {
      currentSection = line.trim();
    }

    // HTMLタグやCSSスタイル属性 (width:100% 等) を除外するための判定
    const cleanText = line.replace(/<[^>]*>/g, '').replace(/style="[^"]*"/g, '').trim();
    if (!cleanText || cleanText.startsWith('<!--') || cleanText.startsWith('//') || cleanText.includes('width:') || cleanText.includes('width=')) {
      return;
    }

    keywords.forEach(kw => {
      if (cleanText.includes(kw)) {
        results.push({
          file: relPath,
          lineNum: lineIdx + 1,
          section: currentSection,
          keyword: kw,
          text: cleanText
        });
      }
    });
  });
});

let reportText = '===============================================================================\n';
reportText += '公開コンテンツ内における過剰な断定表現・強意表現の抽出調査レポート\n';
reportText += '===============================================================================\n';
reportText += '調査日時: 2026年8月7日\n';
reportText += '実施者: Antigravity (Google DeepMind Agentic AI)\n';
reportText += '目的: 改修前の調査・現状可視化（自然言語中の「完全」「完璧」「保証」「保障」「100%」「全て」「確実」等）\n\n';

reportText += `【自然言語テキストでの検出総数: ${results.length} 件】\n\n`;

let currentFile = '';
results.forEach((r, idx) => {
  if (r.file !== currentFile) {
    currentFile = r.file;
    reportText += `-------------------------------------------------------------------------------\n`;
    reportText += `■ 対象ファイル: ${currentFile}\n`;
    reportText += `-------------------------------------------------------------------------------\n`;
  }
  reportText += `[${idx + 1}] L${r.lineNum} (章節/位置: ${r.section}) <検出キーワード: 「${r.keyword}」>\n`;
  reportText += `    該当文: ${r.text}\n\n`;
});

fs.writeFileSync('reports/report_exaggerated_expressions_audit.txt', reportText, 'utf-8');
console.log('Successfully written reports/report_exaggerated_expressions_audit.txt with total:', results.length);
