const fs = require('fs');
const path = require('path');

global.Blockly = require('../js/blockly_compressed.js');
require('../js/blocks_compressed.js');
require('../js/dncl_compressed.js');

Blockly.defineBlocksWithJsonArray([
  { "type": "sound_play", "message0": "🎵 音を鳴らす", "previousStatement": null, "nextStatement": null, "colour": 260 },
  { "type": "say_text", "message0": "💬 %1 と言う", "args0": [{"type": "field_input", "name": "TEXT", "text": "こんにちは！"}], "previousStatement": null, "nextStatement": null, "colour": 160 }
]);

const ws = new Blockly.Workspace();
const b1 = ws.newBlock('say_text');
b1.setFieldValue('テスト表示', 'TEXT');
const b2 = ws.newBlock('sound_play');
b1.nextConnection.connect(b2.previousConnection);

console.log('=== DNCL Robust Conversion Test ===');
const output = Blockly.DNCL.workspaceToCode(ws);
console.log(output);
console.log('=== SUCCESS: DNCL Robust Conversion Worked 100% ===');
