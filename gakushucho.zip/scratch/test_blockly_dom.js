const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const htmlPath = path.join(__dirname, '../learn/gakushucho.html');
const htmlContent = fs.readFileSync(htmlPath, 'utf-8');

console.log('=== Testing DOM Rendering for Blockly Embeds ===');

const dom = new JSDOM(htmlContent, {
  runScripts: 'dangerously',
  resources: 'usable',
  url: 'file://' + htmlPath
});

const document = dom.window.document;

setTimeout(() => {
  const pages = document.querySelectorAll('.section-page');
  console.log('Total SPA Section Pages:', pages.length);

  const embeds = document.querySelectorAll('.blockly-embed-container');
  console.log('Total Blockly Embed Containers:', embeds.length);

  embeds.forEach((container, idx) => {
    const title = container.getAttribute('data-title');
    const preset = container.getAttribute('data-preset');
    const wsDiv = container.querySelector('.blockly-workspace-div');
    const preview = container.querySelector('.code-preview-content');

    console.log(`[Embed ${idx+1}] Title: ${title} (Preset: ${preset})`);
    console.log(`  - Workspace Div Found: ${Boolean(wsDiv)}`);
    console.log(`  - Code Preview Content: ${preview ? preview.textContent.trim().replace(/\n/g, ' ') : 'N/A'}`);
  });

  console.log('\n=== DOM Verification Completed Successfully ===');
  process.exit(0);
}, 1000);
