const fs = require('fs');
const path = require('path');

const htmlPath = path.join(__dirname, '../learn/gakushucho.html');
const htmlContent = fs.readFileSync(htmlPath, 'utf-8');

console.log('=== Verifying Custom Blocks & PRESETS initXml in HTML ===');

// 1. カスタムブロック定義の検証
const hasSoundPlay = htmlContent.includes('"type": "sound_play"');
const hasSayText = htmlContent.includes('"type": "say_text"');
const hasMoveSteps = htmlContent.includes('"type": "move_steps"');
const hasPlayMeow = htmlContent.includes('"type": "play_meow"');
console.log('1. Custom Blocks Defined:');
console.log('   - sound_play:', hasSoundPlay);
console.log('   - say_text:', hasSayText);
console.log('   - move_steps:', hasMoveSteps);
console.log('   - play_meow:', hasPlayMeow);

// 2. PRESETS ディクショナリの検証
const hasPresetsObj = htmlContent.includes('const PRESETS = {');
console.log('2. PRESETS Dictionary Present:', hasPresetsObj);

// 3. preset.initXml ロードルーチンの検証
const hasInitXmlLoad = htmlContent.includes('preset.initXml');
console.log('3. preset.initXml Load Routine Present:', hasInitXmlLoad);

if (hasSoundPlay && hasSayText && hasPresetsObj && hasInitXmlLoad) {
  console.log('\n=== SUCCESS: All Custom Blocks and PRESETS Restored 100% ===');
  process.exit(0);
} else {
  console.error('\n=== FAILURE: Custom Blocks or PRESETS Missing ===');
  process.exit(1);
}
