const fs = require('fs');
const path = require('path');

const pyModule = require('../js/python_compressed.js');
const jsModule = require('../js/javascript_compressed.js');

function getPyGen() {
  if (typeof Blockly !== 'undefined' && Blockly.Python) return Blockly.Python;
  if (typeof python !== 'undefined' && python.pythonGenerator) return python.pythonGenerator;
  if (pyModule && pyModule.pythonGenerator) return pyModule.pythonGenerator;
  return null;
}
function getJsGen() {
  if (typeof Blockly !== 'undefined' && Blockly.JavaScript) return Blockly.JavaScript;
  if (typeof javascript !== 'undefined' && javascript.javascriptGenerator) return javascript.javascriptGenerator;
  if (jsModule && jsModule.javascriptGenerator) return jsModule.javascriptGenerator;
  return null;
}

console.log('PyGen:', Boolean(getPyGen()));
console.log('JsGen:', Boolean(getJsGen()));
